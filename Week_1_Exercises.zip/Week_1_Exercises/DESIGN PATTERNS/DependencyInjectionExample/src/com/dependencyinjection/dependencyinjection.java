package com.dependencyinjection;

import java.util.Scanner;

public class dependencyinjection {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CustomerRepository customerRepository = new CustomerRepositoryImpl();

        CustomerService customerService = new CustomerService(customerRepository);

        System.out.print("Enter customer ID to add: ");
        String addCustomerId = scanner.nextLine();
        System.out.print("Enter customer name to add: ");
        String addCustomerName = scanner.nextLine();

        Customer newCustomer = new Customer(addCustomerId, addCustomerName);
        customerService.addCustomer(newCustomer);
        System.out.println("Customer added successfully.");

        System.out.print("Enter customer ID to find: ");
        String customerId = scanner.nextLine();

        Customer customer = customerService.getCustomerById(customerId);

        if (customer != null) {
            System.out.println("Customer found: " + customer.getName());
        } else {
            System.out.println("Customer not found.");
        }

        scanner.close();
    }
}
