package com.strategypattern;

import java.util.Scanner;

public class StrategyPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PaymentContext context = new PaymentContext();

        System.out.println("Select payment method:");
        System.out.println("1. Credit Card");
        System.out.println("2. GPay");
        System.out.print("Enter choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                System.out.print("Enter card number: ");
                String cardNumber = scanner.nextLine();
                System.out.print("Enter card holder name: ");
                String cardHolderName = scanner.nextLine();
                System.out.print("Enter CVV: ");
                String cvv = scanner.nextLine();
                System.out.print("Enter expiry date (MM/YY): ");
                String expiryDate = scanner.nextLine();
                context.setPaymentStrategy(new CreditCardPayment(cardNumber, cardHolderName, cvv, expiryDate));
                break;
            case 2:
                System.out.print("Enter GPay email: ");
                String email = scanner.nextLine();
                System.out.print("Enter GPay password: ");
                String password = scanner.nextLine();
                context.setPaymentStrategy(new GpayPayment(email, password));
                break;
            default:
                System.out.println("Invalid choice.");
                scanner.close();
                return;
        }

        System.out.print("Enter amount to pay: ");
        double amount = scanner.nextDouble();
        context.executePayment(amount);

        scanner.close();
    }
}

