package com.commandpattern;

import java.util.Scanner;

public class CommandPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Light light = new Light();

        Command lightOn = new LightOnCommand(light);
        Command lightOff = new LightOffCommand(light);

        RemoteControl remote = new RemoteControl();

        boolean lightState = false;

        while (true) {
            System.out.println("Choose an option:");
            System.out.println("1. Turn Light On");
            System.out.println("2. Turn Light Off");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            if (choice == 1) {
                if (!lightState) { // Check if light is off
                    remote.setCommand(lightOn);
                    remote.pressButton();  // Turn the light on
                    lightState = true;
                } else {
                    System.out.println("The light is already ON.");
                }
            } else if (choice == 2) {
                if (lightState) { // Check if light is on
                    remote.setCommand(lightOff);
                    remote.pressButton();  // Turn the light off
                    lightState = false;
                } else {
                    System.out.println("The light is already OFF.");
                }
            } else if (choice == 3) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}

