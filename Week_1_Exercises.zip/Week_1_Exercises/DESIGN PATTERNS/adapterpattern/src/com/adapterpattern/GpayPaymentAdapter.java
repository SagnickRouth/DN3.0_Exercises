package com.adapterpattern;



public class GpayPaymentAdapter implements PaymentProcessor {
    private GpayPaymentGateway GpayPaymentGateway;

    public GpayPaymentAdapter(GpayPaymentGateway GpayPaymentGateway) {
        this.GpayPaymentGateway = GpayPaymentGateway;
    }

    @Override
    public void processPayment(double amount) {
        GpayPaymentGateway.sendPayment(amount);
    }
}
