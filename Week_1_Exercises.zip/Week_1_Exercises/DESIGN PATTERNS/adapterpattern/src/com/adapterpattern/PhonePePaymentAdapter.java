package com.adapterpattern;



public class PhonePePaymentAdapter implements PaymentProcessor {
    private PhonePePaymentGateway PhonePePaymentGateway;

    public PhonePePaymentAdapter(PhonePePaymentGateway stripePaymentGateway) {
        this.PhonePePaymentGateway = PhonePePaymentGateway;
    }

    @Override
    public void processPayment(double amount) {
        PhonePePaymentGateway.makePayment(amount);
    }
}

