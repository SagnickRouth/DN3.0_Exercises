package com.adapterpattern;



import java.util.Scanner;

public class AdapterPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the payment amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine();


        System.out.print("Enter the payment gateway (phonepe/gpay): ");
        String gatewayChoice = scanner.nextLine().trim().toLowerCase();

        PaymentProcessor paymentProcessor = null;



        switch (gatewayChoice) {
            case "phonepe":
                PhonePePaymentGateway PhonepePaymentGateway = new PhonePePaymentGateway();
                paymentProcessor = new PhonePePaymentAdapter(PhonepePaymentGateway);
                break;
            case "gpay":
                GpayPaymentGateway GpayPaymentGateway = new GpayPaymentGateway();
                paymentProcessor = new GpayPaymentAdapter(GpayPaymentGateway);
                break;
            default:
                System.out.println("Invalid payment gateway choice.");
                System.exit(1);
        }

        // Process the payment
        if (paymentProcessor != null) {
            paymentProcessor.processPayment(amount);
        }

        scanner.close();
    }
}
