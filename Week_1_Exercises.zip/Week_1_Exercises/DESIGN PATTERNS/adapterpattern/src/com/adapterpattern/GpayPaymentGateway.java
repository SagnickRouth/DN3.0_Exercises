package com.adapterpattern;



public class GpayPaymentGateway {
    public void sendPayment(double amount) {
        System.out.println("Payment of Rs" + amount + " sent using GPay.");
    }
}
