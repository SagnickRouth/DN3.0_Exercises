package com.adapterpattern;


public class PhonePePaymentGateway {
    public void makePayment(double amount) {
        System.out.println("Payment of Rs" + amount + " made using Stripe.");
    }
}
