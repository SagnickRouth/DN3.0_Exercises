package com.mvcpattern;


import java.util.Scanner;

public class MVCPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter initial student details:");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("ID: ");
        String id = scanner.nextLine();

        System.out.print("Grade: ");
        String grade = scanner.nextLine();

        Student student = new Student(name, id, grade);

        StudentView view = new StudentView();

        StudentController controller = new StudentController(student, view);

        System.out.println("\nInitial Student Details:");
        controller.updateView();

        System.out.println("\nEnter updated student details:");

        System.out.print("New Name: ");
        name = scanner.nextLine();
        controller.setStudentName(name);

        System.out.print("New ID: ");
        id = scanner.nextLine();
        controller.setStudentId(id);

        System.out.print("New Grade: ");
        grade = scanner.nextLine();
        controller.setStudentGrade(grade);

        System.out.println("\nUpdated Student Details:");
        controller.updateView();

        scanner.close();
    }
}
