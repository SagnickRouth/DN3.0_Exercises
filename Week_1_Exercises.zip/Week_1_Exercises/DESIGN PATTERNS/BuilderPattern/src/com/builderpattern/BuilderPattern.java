package com.builderpattern;


public class BuilderPattern {
    public static void main(String[] args) {


        // Basic configuration
        Computer basicComputer = new Computer.Builder()
                .setCPU("Intel i3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        // High-end gaming configuration
        Computer gamingComputer = new Computer.Builder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGPU("NVIDIA RTX 3090")
                .setPowerSupply("750W")
                .setCoolingSystem("Liquid Cooling")
                .build();

        // Workstation configuration
        Computer workstationComputer = new Computer.Builder()
                .setCPU("AMD Ryzen 9")
                .setRAM("64GB")
                .setStorage("2TB NVMe SSD")
                .setGPU("NVIDIA Quadro RTX 5000")
                .setPowerSupply("850W")
                .setCoolingSystem("Air Cooling")
                .build();

        // Print out the configurations
        System.out.println("Basic Computer Configuration: " + basicComputer);
        System.out.println("Gaming Computer Configuration: " + gamingComputer);
        System.out.println("Workstation Computer Configuration: " + workstationComputer);
    }
}
