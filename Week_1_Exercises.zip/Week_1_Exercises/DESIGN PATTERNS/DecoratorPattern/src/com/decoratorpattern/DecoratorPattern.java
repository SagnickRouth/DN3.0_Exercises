package com.decoratorpattern;
import java.util.Scanner;

public class DecoratorPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the notification message: ");
        String message = scanner.nextLine();

        Notifier notifier = null;

        System.out.print("Do you want to send Email notification? (yes/no): ");
        String sendEmail = scanner.nextLine().trim().toLowerCase();
        if (sendEmail.equals("yes")) {
            notifier = new EmailNotifier();
        }

        System.out.print("Do you want to add SMS notifications? (yes/no): ");
        String addSms = scanner.nextLine().trim().toLowerCase();
        if (addSms.equals("yes")) {
            if (notifier == null) {
                notifier = new SMSNotifierDecorator(new Notifier() {
                    @Override
                    public void send(String message) {
                        // No operation
                    }
                });
            } else {
                notifier = new SMSNotifierDecorator(notifier);
            }
        }

        System.out.print("Do you want to add Slack notifications? (yes/no): ");
        String addSlack = scanner.nextLine().trim().toLowerCase();
        if (addSlack.equals("yes")) {
            if (notifier == null) {
                notifier = new SlackNotifierDecorator(new Notifier() {
                    @Override
                    public void send(String message) {
                        // No operation
                    }
                });
            } else {
                notifier = new SlackNotifierDecorator(notifier);
            }
        }

        if (notifier == null) {
            System.out.println("No notification method selected.");
        } else {
            notifier.send(message);
        }

        scanner.close();
    }
}
