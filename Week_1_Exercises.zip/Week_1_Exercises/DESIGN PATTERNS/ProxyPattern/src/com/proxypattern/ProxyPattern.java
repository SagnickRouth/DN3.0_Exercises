package com.proxypattern;



import java.util.Scanner;

public class ProxyPattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the name of the image file (with path) to display: ");
        String fileName = scanner.nextLine();

        Image image = new ProxyImage(fileName);

        // First time loading and displaying the image
        System.out.println("First time displaying:");
        image.display();

        // Displaying the image again (should use cached image)
        System.out.println("\nSecond time displaying:");
        image.display();

        scanner.close();
    }
}
