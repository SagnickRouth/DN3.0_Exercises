import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


interface Identifiable {
    String getId();
}

interface CustomerInfo {
    String getCustomerName();
}

interface Priceable {
    double getTotalPrice();
}


interface Order extends Identifiable, CustomerInfo, Priceable {
}


class SimpleOrder implements Order {
    private String orderId;
    private String customerName;
    private double totalPrice;

    public SimpleOrder(String orderId, String customerName, double totalPrice) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }

    @Override
    public String getId() {
        return orderId;
    }

    @Override
    public String getCustomerName() {
        return customerName;
    }

    @Override
    public double getTotalPrice() {
        return totalPrice;
    }

    @Override
    public String toString() {
        return "Order{id='" + orderId + "', customer='" + customerName + "', price=" + totalPrice + "}";
    }
}


class OrderComparator implements Comparator<Order> {
    private String criteria;

    public OrderComparator(String criteria) {
        this.criteria = criteria;
    }

    @Override
    public int compare(Order o1, Order o2) {
        switch (criteria) {
            case "id":
                return o1.getId().compareTo(o2.getId());
            case "name":
                return o1.getCustomerName().compareTo(o2.getCustomerName());
            case "price":
                return Double.compare(o1.getTotalPrice(), o2.getTotalPrice());
            default:
                throw new IllegalArgumentException("Unknown sorting criteria: " + criteria);
        }
    }
}


interface SortingAlgorithm {
    void sort(List<? extends Order> orders, Comparator<Order> comparator);
}


class BubbleSort implements SortingAlgorithm {
    @Override
    public void sort(List<? extends Order> orders, Comparator<Order> comparator) {
        int n = orders.size();
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (comparator.compare(orders.get(j), orders.get(j + 1)) > 0) {
                    Order temp = orders.get(j);
                    ((List<Order>) orders).set(j, orders.get(j + 1));
                    ((List<Order>) orders).set(j + 1, temp);
                }
            }
        }
    }
}


class QuickSort implements SortingAlgorithm {
    @Override
    public void sort(List<? extends Order> orders, Comparator<Order> comparator) {
        quickSort(orders, 0, orders.size() - 1, comparator);
    }

    private void quickSort(List<? extends Order> orders, int low, int high, Comparator<Order> comparator) {
        if (low < high) {
            int pi = partition(orders, low, high, comparator);
            quickSort(orders, low, pi - 1, comparator);
            quickSort(orders, pi + 1, high, comparator);
        }
    }

    private int partition(List<? extends Order> orders, int low, int high, Comparator<Order> comparator) {
        Order pivot = orders.get(high);
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (comparator.compare(orders.get(j), pivot) <= 0) {
                i++;
                Order temp = orders.get(i);
                ((List<Order>) orders).set(i, orders.get(j));
                ((List<Order>) orders).set(j, temp);
            }
        }
        Order temp = orders.get(i + 1);
        ((List<Order>) orders).set(i + 1, orders.get(high));
        ((List<Order>) orders).set(high, temp);
        return i + 1;
    }
}


interface OrderRepository {
    void addOrder(Order order);
    List<? extends Order> getOrders();
}


class InMemoryOrderRepository implements OrderRepository {
    private List<Order> orders;

    public InMemoryOrderRepository() {
        orders = new ArrayList<>();
    }

    @Override
    public void addOrder(Order order) {
        orders.add(order);
    }

    @Override
    public List<? extends Order> getOrders() {
        return new ArrayList<>(orders);
    }
}


class SortingService {
    private OrderRepository repository;
    private SortingAlgorithm bubbleSort;
    private SortingAlgorithm quickSort;

    public SortingService(OrderRepository repository, SortingAlgorithm bubbleSort, SortingAlgorithm quickSort) {
        this.repository = repository;
        this.bubbleSort = bubbleSort;
        this.quickSort = quickSort;
    }

    public void sortOrders(String criteria) {
        List<Order> bubbleSortOrders = new ArrayList<>(repository.getOrders());
        List<Order> quickSortOrders = new ArrayList<>(repository.getOrders());
        Comparator<Order> comparator = new OrderComparator(criteria);

        long startTime, endTime;


        startTime = System.nanoTime();
        bubbleSort.sort(bubbleSortOrders, comparator);
        endTime = System.nanoTime();
        long bubbleSortTime = endTime - startTime;


        startTime = System.nanoTime();
        quickSort.sort(quickSortOrders, comparator);
        endTime = System.nanoTime();
        long quickSortTime = endTime - startTime;


        System.out.println("\nSorted Orders by " + criteria + ":");
        for (Order order : quickSortOrders) {
            System.out.println(order);
        }

        System.out.println("\nBubble Sort Time: " + bubbleSortTime + " ns");
        System.out.println("Quick Sort Time: " + quickSortTime + " ns");
    }
}


public class CustomerOrderSorting {
    public static void main(String[] args) {
        OrderRepository repository = new InMemoryOrderRepository();
        SortingAlgorithm bubbleSort = new BubbleSort();
        SortingAlgorithm quickSort = new QuickSort();
        SortingService sortingService = new SortingService(repository, bubbleSort, quickSort);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nCustomer Order Sorting System");
            System.out.println("1. Add Order");
            System.out.println("2. Sort Orders");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Order ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Customer Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Total Price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    repository.addOrder(new SimpleOrder(id, name, price));
                    System.out.println("Order added successfully.");
                    break;
                case 2:
                    System.out.println("Select sorting criteria:");
                    System.out.println("1. Order ID");
                    System.out.println("2. Customer Name");
                    System.out.println("3. Total Price");
                    System.out.print("Enter your choice: ");
                    int criteriaChoice = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    String criteria;
                    switch (criteriaChoice) {
                        case 1:
                            criteria = "id";
                            break;
                        case 2:
                            criteria = "name";
                            break;
                        case 3:
                            criteria = "price";
                            break;
                        default:
                            System.out.println("Invalid choice. Sorting by Total Price by default.");
                            criteria = "price";
                            break;
                    }

                    sortingService.sortOrders(criteria);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
