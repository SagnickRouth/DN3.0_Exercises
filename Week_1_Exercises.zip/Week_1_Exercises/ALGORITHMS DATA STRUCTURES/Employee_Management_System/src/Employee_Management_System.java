import java.util.*;
class Employee {
    private String employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(String employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{id='" + employeeId + "', name='" + name + "', position='" + position + "', salary=" + salary + "}";
    }
}
interface EmployeeRepository {
    void addEmployee(Employee employee);
    Employee searchEmployeeById(String employeeId);
    void traverseEmployees();
    void deleteEmployeeById(String employeeId);
}
class ArrayEmployeeRepository implements EmployeeRepository {
    private Employee[] employees;
    private int count;

    public ArrayEmployeeRepository(int capacity) {
        employees = new Employee[capacity];
        count = 0;
    }

    @Override
    public void addEmployee(Employee employee) {
        if (count >= employees.length) {
            System.out.println("Array is full. Cannot add more employees.");
            return;
        }
        employees[count++] = employee;
    }

    @Override
    public Employee searchEmployeeById(String employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                return employees[i];
            }
        }
        return null;
    }

    @Override
    public void traverseEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }

    @Override
    public void deleteEmployeeById(String employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId().equals(employeeId)) {
                employees[i] = employees[--count];
                employees[count] = null;
                return;
            }
        }
        System.out.println("Employee not found.");
    }
}


public class Employee_Management_System {
    public static void main(String[] args) {
        EmployeeRepository repository = new ArrayEmployeeRepository(10); // Capacity set to 10 for demo
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nEmployee Management System");
            System.out.println("1. Add Employee");
            System.out.println("2. Search Employee by ID");
            System.out.println("3. Traverse Employees");
            System.out.println("4. Delete Employee by ID");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Position: ");
                    String position = scanner.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = scanner.nextDouble();
                    scanner.nextLine(); // Consume newline
                    repository.addEmployee(new Employee(id, name, position, salary));
                    System.out.println("Employee added successfully.");
                    break;
                case 2:
                    System.out.print("Enter Employee ID to search: ");
                    id = scanner.nextLine();
                    Employee employee = repository.searchEmployeeById(id);
                    if (employee != null) {
                        System.out.println("Employee found: " + employee);
                    } else {
                        System.out.println("Employee not found.");
                    }
                    break;
                case 3:
                    System.out.println("Traversing Employees:");
                    repository.traverseEmployees();
                    break;
                case 4:
                    System.out.print("Enter Employee ID to delete: ");
                    id = scanner.nextLine();
                    repository.deleteEmployeeById(id);
                    System.out.println("Employee deletion attempted.");
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
