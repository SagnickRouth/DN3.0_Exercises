import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;


class Book {
    private String bookId;
    private String title;
    private String author;

    public Book(String bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }

    public String getBookId() {
        return bookId;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    @Override
    public String toString() {
        return "Book{id='" + bookId + "', title='" + title + "', author='" + author + "'}";
    }
}


interface SearchAlgorithm {
    List<Book> search(List<Book> books, String keyword);
}

class LinearSearch implements SearchAlgorithm {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(keyword)) {
                result.add(book);
            }
        }
        return result;
    }
}

class BinarySearch implements SearchAlgorithm {
    @Override
    public List<Book> search(List<Book> books, String keyword) {
        List<Book> result = new ArrayList<>();
        int left = 0;
        int right = books.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int compare = books.get(mid).getTitle().compareToIgnoreCase(keyword);
            if (compare == 0) {
                result.add(books.get(mid));
                break;
            } else if (compare < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return result;
    }
}


interface BookRepository {
    void addBook(Book book);
    List<Book> getBooks();
}

// Dependency Inversion Principle: In-memory book repository
class InMemoryBookRepository implements BookRepository {
    private List<Book> books;

    public InMemoryBookRepository() {
        books = new ArrayList<>();
    }

    @Override
    public void addBook(Book book) {
        books.add(book);
        books.sort(Comparator.comparing(Book::getTitle));
    }

    @Override
    public List<Book> getBooks() {
        return new ArrayList<>(books);
    }
}


public class LibraryManagementSystem {
    public static void main(String[] args) {
        BookRepository repository = new InMemoryBookRepository();
        SearchAlgorithm linearSearch = new LinearSearch();
        SearchAlgorithm binarySearch = new BinarySearch();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add Book");
            System.out.println("2. Search Book by Title (Linear Search)");
            System.out.println("3. Search Book by Title (Binary Search)");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Book ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter Author: ");
                    String author = scanner.nextLine();
                    repository.addBook(new Book(id, title, author));
                    System.out.println("Book added successfully.");
                    break;
                case 2:
                    System.out.print("Enter Title to Search: ");
                    String searchTitleLinear = scanner.nextLine();
                    List<Book> linearResults = linearSearch.search(repository.getBooks(), searchTitleLinear);
                    System.out.println("Search Results (Linear Search):");
                    for (Book book : linearResults) {
                        System.out.println(book);
                    }
                    break;
                case 3:
                    System.out.print("Enter Title to Search: ");
                    String searchTitleBinary = scanner.nextLine();
                    List<Book> binaryResults = binarySearch.search(repository.getBooks(), searchTitleBinary);
                    System.out.println("Search Results (Binary Search):");
                    for (Book book : binaryResults) {
                        System.out.println(book);
                    }
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
