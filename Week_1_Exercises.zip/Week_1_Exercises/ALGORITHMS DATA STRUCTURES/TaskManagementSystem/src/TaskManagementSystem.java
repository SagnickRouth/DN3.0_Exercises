import java.util.*;
class Task {
    private String taskId;
    private String taskName;
    private String status;

    public Task(String taskId, String taskName, String status) {
        this.taskId = taskId;
        this.taskName = taskName;
        this.status = status;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public String getStatus() {
        return status;
    }

    @Override
    public String toString() {
        return "Task{id='" + taskId + "', name='" + taskName + "', status='" + status + "'}";
    }
}


class TaskNode {
    private Task task;
    private TaskNode next;

    public TaskNode(Task task) {
        this.task = task;
    }

    public Task getTask() {
        return task;
    }

    public TaskNode getNext() {
        return next;
    }

    public void setNext(TaskNode next) {
        this.next = next;
    }
}


interface TaskRepository {
    void addTask(Task task);
    Task searchTask(String taskId);
    void traverseTasks();
    void deleteTask(String taskId);
}


class SinglyLinkedListTaskRepository implements TaskRepository {
    private TaskNode head;

    @Override
    public void addTask(Task task) {
        TaskNode newNode = new TaskNode(task);
        if (head == null) {
            head = newNode;
        } else {
            TaskNode current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    @Override
    public Task searchTask(String taskId) {
        TaskNode current = head;
        while (current != null) {
            if (current.getTask().getTaskId().equals(taskId)) {
                return current.getTask();
            }
            current = current.getNext();
        }
        return null;
    }

    @Override
    public void traverseTasks() {
        TaskNode current = head;
        while (current != null) {
            System.out.println(current.getTask());
            current = current.getNext();
        }
    }

    @Override
    public void deleteTask(String taskId) {
        if (head == null) {
            System.out.println("Task not found.Can't be deleted.");
            return;
        }

        if (head.getTask().getTaskId().equals(taskId)) {
            head = head.getNext();
            System.out.println("Task deleted successfully.");
            return;
        }

        TaskNode current = head;
        TaskNode previous = null;

        while (current != null && !current.getTask().getTaskId().equals(taskId)) {
            previous = current;
            current = current.getNext();
        }

        if (current != null) {
            previous.setNext(current.getNext());
            System.out.println("Task deleted successfully.");
        } else {
            System.out.println("Task not found.");
        }
    }
}


public class TaskManagementSystem {
    public static void main(String[] args) {
        TaskRepository taskRepository = new SinglyLinkedListTaskRepository();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nTask Management System");
            System.out.println("1. Add Task");
            System.out.println("2. Search Task");
            System.out.println("3. Traverse Tasks");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter Task ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Task Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Task Status: ");
                    String status = scanner.nextLine();
                    taskRepository.addTask(new Task(id, name, status));
                    System.out.println("Task added successfully.");
                    break;
                case 2:
                    System.out.print("Enter Task ID to search: ");
                    id = scanner.nextLine();
                    Task task = taskRepository.searchTask(id);
                    if (task != null) {
                        System.out.println("Task found: " + task);
                    } else {
                        System.out.println("Task not found.");
                    }
                    break;
                case 3:
                    System.out.println("Traversing tasks:");
                    taskRepository.traverseTasks();
                    break;
                case 4:
                    System.out.print("Enter Task ID to delete: ");
                    id = scanner.nextLine();
                    taskRepository.deleteTask(id);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
