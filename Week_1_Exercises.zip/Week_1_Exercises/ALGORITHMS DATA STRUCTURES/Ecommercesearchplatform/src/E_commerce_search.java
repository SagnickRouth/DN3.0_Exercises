import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;


interface Identifiable {
    String getId();
}

interface Nameable {
    String getName();
}

interface Categorizable {
    String getCategory();
}

interface Product extends Identifiable, Nameable, Categorizable, Comparable<Product> {
}

class SimpleProduct implements Product {
    private String id;
    private String name;
    private String category;

    public SimpleProduct(String id, String name, String category) {
        this.id = id;
        this.name = name;
        this.category = category;
    }

    @Override
    public String getId() { return id; }

    @Override
    public String getName() { return name; }

    @Override
    public String getCategory() { return category; }

    @Override
    public int compareTo(Product other) {
        return this.getId().compareTo(other.getId());
    }

    @Override
    public String toString() {
        return "Product{id='" + id + "', name='" + name + "', category='" + category + "'}";
    }
}


interface SearchAlgorithm {
    int search(List<? extends Product> products, String searchId);
}

class LinearSearch implements SearchAlgorithm {
    @Override
    public int search(List<? extends Product> products, String searchId) {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId().equals(searchId)) {
                return i;
            }
        }
        return -1;
    }
}

class BinarySearch implements SearchAlgorithm {
    @Override
    public int search(List<? extends Product> products, String searchId) {
        int left = 0;
        int right = products.size() - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products.get(mid).getId().compareTo(searchId);

            if (comparison == 0) {
                return mid;
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1;
    }
}

interface ProductRepository {
    void addProduct(Product product);
    List<? extends Product> getProducts();
    List<? extends Product> getSortedProducts();
}

class InMemoryProductRepository implements ProductRepository {
    private List<Product> products;
    private List<Product> sortedProducts;

    public InMemoryProductRepository() {
        products = new ArrayList<>();
        sortedProducts = new ArrayList<>();
    }

    @Override
    public void addProduct(Product product) {
        products.add(product);
        sortedProducts.add(product);
        Collections.sort(sortedProducts);
    }

    @Override
    public List<? extends Product> getProducts() {
        return new ArrayList<>(products);
    }

    @Override
    public List<? extends Product> getSortedProducts() {
        return new ArrayList<>(sortedProducts);
    }
}

class SearchService {
    private ProductRepository repository;
    private SearchAlgorithm linearSearch;
    private SearchAlgorithm binarySearch;

    public SearchService(ProductRepository repository, SearchAlgorithm linearSearch, SearchAlgorithm binarySearch) {
        this.repository = repository;
        this.linearSearch = linearSearch;
        this.binarySearch = binarySearch;
    }

    public void searchProduct(String searchId) {
        long startTime, endTime;


        startTime = System.nanoTime();
        int linearResult = linearSearch.search(repository.getProducts(), searchId);
        endTime = System.nanoTime();
        long linearTime = endTime - startTime;


        startTime = System.nanoTime();
        int binaryResult = binarySearch.search(repository.getSortedProducts(), searchId);
        endTime = System.nanoTime();
        long binaryTime = endTime - startTime;

        // Print results
        System.out.println("\nSearch Results for ID: " + searchId);
        if (linearResult != -1) {
            System.out.println("Product found: " + repository.getProducts().get(linearResult));
        } else {
            System.out.println("Product not found.");
        }

        System.out.println("Linear Search Time: " + linearTime + " ns");
        System.out.println("Binary Search Time: " + binaryTime + " ns");
    }
}

public class E_commerce_search {
    public static void main(String[] args) {
        ProductRepository repository = new InMemoryProductRepository();
        SearchAlgorithm linearSearch = new LinearSearch();
        SearchAlgorithm binarySearch = new BinarySearch();
        SearchService searchService = new SearchService(repository, linearSearch, binarySearch);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nE-commerce Platform Search Function");
            System.out.println("1. Add Product");
            System.out.println("2. Search Product");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Product ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Product Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Product Category: ");
                    String category = scanner.nextLine();
                    repository.addProduct(new SimpleProduct(id, name, category));
                    System.out.println("Product added successfully.");
                    break;
                case 2:
                    System.out.print("Enter Product ID to search: ");
                    String searchId = scanner.nextLine();
                    searchService.searchProduct(searchId);
                    break;
                case 3:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}