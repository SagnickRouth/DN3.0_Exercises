import java.util.*;


interface Identifiable {
    String getId();
}

interface Nameable {
    String getName();
}

interface Valuable {
    double getValue();
}


interface Product extends Identifiable, Nameable, Valuable {
    double getBasePrice();
}
abstract class AbstractProduct implements Product {
    protected String id;
    protected String name;
    protected double basePrice;

    public AbstractProduct(String id, String name, double basePrice) {
        this.id = id;
        this.name = name;
        this.basePrice = basePrice;
    }

    @Override
    public String getId() { return id; }

    @Override
    public String getName() { return name; }

    @Override
    public double getBasePrice() { return basePrice; }
}



class ElectronicProduct extends AbstractProduct {
    private int warrantyPeriod;

    public ElectronicProduct(String id, String name, double basePrice, int warrantyPeriod) {
        super(id, name, basePrice);
        this.warrantyPeriod = warrantyPeriod;
    }

    @Override
    public double getValue() {
        return basePrice * (1 + warrantyPeriod / 12.0);
    }
}

class BookProduct extends AbstractProduct {
    private String author;

    public BookProduct(String id, String name, double basePrice, String author) {
        super(id, name, basePrice);
        this.author = author;
    }

    @Override
    public double getValue() {
        return basePrice;
    }
}


interface ProductRepository {
    void addProduct(Product product);
    void removeProduct(String productId);
    Product getProduct(String productId);
    List<Product> getAllProducts();
}

class InMemoryProductRepository implements ProductRepository {
    private Map<String, Product> products = new HashMap<>();

    @Override
    public void addProduct(Product product) {
        products.put(product.getId(), product);
    }

    @Override
    public void removeProduct(String productId) {
        products.remove(productId);
    }

    @Override
    public Product getProduct(String productId) {
        return products.get(productId);
    }

    @Override
    public List<Product> getAllProducts() {
        return new ArrayList<>(products.values());
    }
}


interface PricingStrategy {
    double calculatePrice(Product product);
}

class RegularPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(Product product) {
        return product.getValue();
    }
}

class DiscountPricingStrategy implements PricingStrategy {
    private double discountPercentage;

    public DiscountPricingStrategy(double discountPercentage) {
        this.discountPercentage = discountPercentage;
    }

    @Override
    public double calculatePrice(Product product) {
        return product.getValue() * (1 - discountPercentage);
    }
}


interface ProductFactory {
    Product createProduct(String id, String name, double basePrice);
}

class ElectronicProductFactory implements ProductFactory {
    private int warrantyPeriod;

    public ElectronicProductFactory(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    @Override
    public Product createProduct(String id, String name, double basePrice) {
        return new ElectronicProduct(id, name, basePrice, warrantyPeriod);
    }
}

class BookProductFactory implements ProductFactory {
    private String defaultAuthor;

    public BookProductFactory(String defaultAuthor) {
        this.defaultAuthor = defaultAuthor;
    }

    @Override
    public Product createProduct(String id, String name, double basePrice) {
        return new BookProduct(id, name, basePrice, defaultAuthor);
    }
}


abstract class ProductDecorator implements Product {
    protected Product decoratedProduct;

    public ProductDecorator(Product decoratedProduct) {
        this.decoratedProduct = decoratedProduct;
    }

    @Override
    public String getId() { return decoratedProduct.getId(); }

    @Override
    public String getName() { return decoratedProduct.getName(); }

    @Override
    public double getValue() { return decoratedProduct.getValue(); }

    @Override
    public double getBasePrice() { return decoratedProduct.getBasePrice(); }
}



class GiftWrappedProduct extends ProductDecorator {
    private double wrappingCost;

    public GiftWrappedProduct(Product decoratedProduct, double wrappingCost) {
        super(decoratedProduct);
        this.wrappingCost = wrappingCost;
    }

    @Override
    public double getValue() {
        return super.getValue() + wrappingCost;
    }

    @Override
    public String getName() {
        return "Gift Wrapped " + super.getName();
    }

    @Override
    public double getBasePrice() {
        return super.getBasePrice() + wrappingCost;
    }
}


interface InventoryObserver {
    void update(Product product);
}

class InventoryManager implements ProductRepository {
    private ProductRepository repository;
    private List<InventoryObserver> observers = new ArrayList<>();

    public InventoryManager(ProductRepository repository) {
        this.repository = repository;
    }

    public void addObserver(InventoryObserver observer) {
        observers.add(observer);
    }

    private void notifyObservers(Product product) {
        for (InventoryObserver observer : observers) {
            observer.update(product);
        }
    }

    @Override
    public void addProduct(Product product) {
        repository.addProduct(product);
        notifyObservers(product);
    }

    @Override
    public void removeProduct(String productId) {
        repository.removeProduct(productId);
    }

    @Override
    public Product getProduct(String productId) {
        return repository.getProduct(productId);
    }

    @Override
    public List<Product> getAllProducts() {
        return repository.getAllProducts();
    }
}

class InventoryReporter implements InventoryObserver {
    private PricingStrategy pricingStrategy;

    public InventoryReporter(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    @Override
    public void update(Product product) {
        double price = pricingStrategy.calculatePrice(product);
        System.out.println("New product added: " + product.getName() + " - Price: Rs" + price);
    }

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public void generateReport(List<Product> products) {
        for (Product product : products) {
            double price = pricingStrategy.calculatePrice(product);
            System.out.println(product.getName() + " - Price: Rs" + price);
        }
    }
}



public class InventoryManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductRepository repository = new InMemoryProductRepository();
        InventoryManager inventoryManager = new InventoryManager(repository);

        PricingStrategy regularPricing = new RegularPricingStrategy();
        InventoryReporter reporter = new InventoryReporter(regularPricing);
        inventoryManager.addObserver(reporter);

        ProductFactory electronicFactory = new ElectronicProductFactory(12);
        ProductFactory bookFactory = new BookProductFactory("Unknown Author");

        while (true) {
            System.out.println("\nInventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. Remove Product");
            System.out.println("3. Generate Report");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    addProduct(scanner, inventoryManager, electronicFactory, bookFactory);
                    break;
                case 2:
                    removeProduct(scanner, inventoryManager);
                    break;
                case 3:
                    generateReport(scanner, reporter, inventoryManager);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addProduct(Scanner scanner, InventoryManager inventoryManager,
                                   ProductFactory electronicFactory, ProductFactory bookFactory) {
        System.out.print("Enter product type (1 for Electronic, 2 for Book): ");
        int type = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter product ID: ");
        String id = scanner.nextLine();

        System.out.print("Enter product name: ");
        String name = scanner.nextLine();

        System.out.print("Enter base price: ");
        double basePrice = scanner.nextDouble();
        scanner.nextLine();

        Product product;
        if (type == 1) {
            product = electronicFactory.createProduct(id, name, basePrice);
        } else if (type == 2) {
            product = bookFactory.createProduct(id, name, basePrice);
        } else {
            System.out.println("Invalid product type.");
            return;
        }

        System.out.print("Gift wrap the product? (y/n): ");
        String giftWrap = scanner.nextLine();
        if (giftWrap.equalsIgnoreCase("y")) {
            System.out.print("Enter wrapping cost: ");
            double wrappingCost = scanner.nextDouble();
            scanner.nextLine();
            product = new GiftWrappedProduct(product, wrappingCost);
        }

        inventoryManager.addProduct(product);
        System.out.println("Product added successfully.");
    }

    private static void removeProduct(Scanner scanner, InventoryManager inventoryManager) {
        System.out.print("Enter product ID to remove: ");
        String id = scanner.nextLine();
        inventoryManager.removeProduct(id);
        System.out.println("Product removed (if it existed).");
    }

    private static void generateReport(Scanner scanner, InventoryReporter reporter, InventoryManager inventoryManager) {
        System.out.print("Enter pricing strategy (1 for Regular, 2 for Discount): ");
        int strategyChoice = scanner.nextInt();
        scanner.nextLine();

        PricingStrategy strategy;
        if (strategyChoice == 1) {
            strategy = new RegularPricingStrategy();
        } else if (strategyChoice == 2) {
            System.out.print("Enter discount percentage (0-100): ");
            double discountPercentage = scanner.nextDouble() / 100.0;
            scanner.nextLine();
            strategy = new DiscountPricingStrategy(discountPercentage);
        } else {
            System.out.println("Invalid strategy choice. Using regular pricing.");
            strategy = new RegularPricingStrategy();
        }

        reporter.setPricingStrategy(strategy);
        System.out.println("\nInventory Report:");
        reporter.generateReport(inventoryManager.getAllProducts());
    }
}