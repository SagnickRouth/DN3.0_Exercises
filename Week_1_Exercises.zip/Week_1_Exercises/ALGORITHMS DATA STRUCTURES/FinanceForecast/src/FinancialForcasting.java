import java.util.Scanner;


interface FinancialForecast {
    double calculateFutureValue(double initialValue, double growthRate, int years);
}


class RecursiveFinancialForecast implements FinancialForecast {
    @Override
    public double calculateFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return (1 + growthRate) * calculateFutureValue(initialValue, growthRate, years - 1);
    }
}


class OptimizedRecursiveFinancialForecast implements FinancialForecast {
    private double[] memo;

    @Override
    public double calculateFutureValue(double initialValue, double growthRate, int years) {
        memo = new double[years + 1];
        for (int i = 0; i <= years; i++) {
            memo[i] = -1;
        }
        return calculateFutureValueHelper(initialValue, growthRate, years);
    }

    private double calculateFutureValueHelper(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        if (memo[years] != -1) {
            return memo[years];
        }
        memo[years] = (1 + growthRate) * calculateFutureValueHelper(initialValue, growthRate, years - 1);
        return memo[years];
    }
}


public class FinancialForcasting {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the initial value: ");
        double initialValue = scanner.nextDouble();

        System.out.print("Enter the growth rate (as a decimal, e.g., 0.05 for 5%): ");
        double growthRate = scanner.nextDouble();

        System.out.print("Enter the number of years: ");
        int years = scanner.nextInt();

        FinancialForecast recursiveForecast = new RecursiveFinancialForecast();
        FinancialForecast optimizedForecast = new OptimizedRecursiveFinancialForecast();

        System.out.println("Recursive Forecast:");
        System.out.println("Future Value: " + recursiveForecast.calculateFutureValue(initialValue, growthRate, years));

        System.out.println("\nOptimized Recursive Forecast:");
        System.out.println("Future Value: " + optimizedForecast.calculateFutureValue(initialValue, growthRate, years));

        scanner.close();
    }
}
